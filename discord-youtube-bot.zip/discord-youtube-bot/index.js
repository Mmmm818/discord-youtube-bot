// Developed by Alz3eam - Programmer & Developer
require('dotenv').config();
const { Client, GatewayIntentBits } = require('discord.js');
const axios = require('axios');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent
    ]
});

const DISCORD_CHANNEL_ID = process.env.DISCORD_CHANNEL_ID;
const API_KEY = process.env.YOUTUBE_API_KEY;
const YOUTUBE_CHANNEL_ID = process.env.TARGET_CHANNEL_ID;

let lastVideoId = '';

async function checkNewVideo() {
    try {
        const url = `https://www.googleapis.com/youtube/v3/search?key=${API_KEY}&channelId=${YOUTUBE_CHANNEL_ID}&part=snippet,id&order=date&maxResults=1`;
        const response = await axios.get(url);
        const videos = response.data.items;

        if (Array.isArray(videos) && videos.length > 0 && videos[0].id && videos[0].id.videoId) {
            const latestVideoId = videos[0].id.videoId;

            if (latestVideoId !== lastVideoId) {
                lastVideoId = latestVideoId;
                const videoUrl = `https://www.youtube.com/watch?v=${latestVideoId}`;

                const channel = await client.channels.fetch(DISCORD_CHANNEL_ID);
                if (channel && channel.isTextBased()) {
                    await channel.send(`🚀 جديد على يوتيوب! ${videoUrl}`);
                }

                console.log(`تم إرسال فيديو جديد: ${videoUrl}`);
            }
        }
    } catch (error) {
        console.error('خطأ أثناء التحقق من الفيديوهات:', error);
    }
}

client.once('ready', () => {
    console.log(`البوت شغال باسم ${client.user.tag}`);

    checkNewVideo(); // فحص أولي عند التشغيل
    setInterval(checkNewVideo, 10 * 60 * 1000); // كل 10 دقائق
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    if (message.content.startsWith('!يوتيوب')) {
        const args = message.content.split(' ');
        if (args.length < 2) {
            return message.reply('رجاءً أدخل رابط الفيديو بشكل صحيح، مثلا: !يوتيوب https://youtube.com/...');
        }

        const videoUrl = args[1];
        const targetChannel = await client.channels.fetch(DISCORD_CHANNEL_ID);

        if (targetChannel && targetChannel.isTextBased()) {
            await targetChannel.send({ content: `@everyone فيديو من اليوتيوب متنساش تشترك بالقناة:
${videoUrl}` });
        }
    }
});

client.login(process.env.DISCORD_TOKEN);
// Developed by Alz3eam - Programmer & Developer
